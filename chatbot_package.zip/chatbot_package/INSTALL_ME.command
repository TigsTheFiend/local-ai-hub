{\rtf1\ansi\ansicpg1252\cocoartf2870
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 #!/bin/bash\
\
clear\
echo "====================================================="\
echo "  \uc0\u55356 \u57261  WELCOME TO THE LOCAL AI ROLEPLAY HUB"\
echo "====================================================="\
echo "Setting up your private, offline story sandbox..."\
echo "----------------------------------------------------"\
\
# 1. Quietly setup local folders on their machine\
mkdir -p ~/personalities/ai_roles\
mkdir -p ~/personalities/user_roles\
mkdir -p ~/personalities/world_settings\
mkdir -p ~/saves\
\
# 2. Copy the game files to their local hard drive\
SCRIPT_DIR="$( cd "$( dirname "$\{BASH_SOURCE[0]\}" )" && pwd )"\
cp "$SCRIPT_DIR/chatbot.py" ~/chatbot.py\
\
# 3. Create a beautiful, permanent launcher shortcut on their Desktop\
cat << 'EOF' > ~/Desktop/Start_AI_Hub.command\
#!/bin/bash\
cd ~\
clear\
python3 ~/chatbot.py\
$SHELL\
EOF\
\
# 4. Make the desktop shortcut clickable with a double-click\
chmod +x ~/Desktop/Start_AI_Hub.command\
\
echo "----------------------------------------------------"\
echo "\uc0\u55356 \u57225  SETUP COMPLETED SUCCESSFULLY!"\
echo "\uc0\u10024  You can close this window now."\
echo "\uc0\u55356 \u57262  A permanent launch shortcut has been added to your Desktop!"\
echo "====================================================="}